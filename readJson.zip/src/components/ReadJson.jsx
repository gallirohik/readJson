import React, { Component } from "react";
import LoaderHOC from "./HOC/LoaderHOC";
class ReadJson extends Component {
  state = {};

  render() {
    const styles = {
      backgroundColor: "#999"
    };

    const bstyles = {
      border: "1px solid black",
      margin: "5px 5px 5px 5px",
      marginTop: "5px",
      padding: "5px",
      borderRadius: "5px"
    };
    return this.props.records.map(record => {
      const { title, first, last } = record.name;
      const name = title + ". " + first + " " + last;
      const pStyles = {
        height: "50px",
        width: "50px",
        backgroundImage: `url('${record.picture.thumbnail}')`
      };
      return (
        <div id="container-b" style={bstyles}>
          <div id="picture" style={pStyles} />
          <div className="details" style={styles}>
            <p>Name: {name}</p>
            <p>Email: {record.email}</p>
          </div>
        </div>
      );
    });
  }
}

export default LoaderHOC(ReadJson);
