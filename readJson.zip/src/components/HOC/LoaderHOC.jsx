import React, { Component } from "react";
import "./loader.css";
const LoaderHOC = WrappedComponent => {
  return class LoaderHOC extends Component {
    handleLoad = () => {
      const loader = document.querySelector(".loader");
      loader.className += " hidden";
    };
    componentDidMount() {
      window.addEventListener("load", this.handleLoad);
    }
    render() {
      return this.props.records.length === 0 ? (
        <div>
          <div className="loader" id="loaderId">
            <h1>loading...</h1>
            <img src={"https://i.redd.it/ounq1mw5kdxy.gif"} alt="loader" />;
            <br />
          </div>
        </div>
      ) : (
        <WrappedComponent {...this.props} />
      );
    }
  };
};
export default LoaderHOC;
