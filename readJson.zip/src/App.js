import React, { Component } from "react";
import "./App.css";
import ReadJson from "./components/ReadJson";
class App extends Component {
  constructor(props) {
    super(props);
    this.state = {
      Records: []
    };
  }
  // handleLoad = () => {
  //   const loader = document.querySelector(".loader");
  //   loader.className += " hidden";
  // };
  componentDidMount() {
    // window.addEventListener("load", this.handleLoad);
    const url = "https://randomuser.me/api/?nat=us.gb&results=50";
    fetch(url)
      .then(response => response.json())
      .then(data => {
        this.setState({ Records: data.results });
      });
  }

  render() {
    return (
      <div>
        <div id="container">
          <ReadJson records={this.state.Records} />;
        </div>
      </div>
    );
  }
}

export default App;
